-- Ejecutar UNA VEZ en phpMyAdmin, seleccionando la base `6hospi`.
-- No modifica pacientes, medicos, tratamientos ni los datos existentes.
-- Se puede volver a ejecutar: las tablas y asignaciones usan IF NOT EXISTS / IGNORE.

CREATE TABLE IF NOT EXISTS roles (
  id_rol INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) NOT NULL UNIQUE,
  nombre VARCHAR(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS permisos (
  id_permiso INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(60) NOT NULL UNIQUE,
  descripcion VARCHAR(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  id_medico INT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_usuario_medico FOREIGN KEY (id_medico)
    REFERENCES medicos(id_medico) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuario_roles (
  id_usuario INT NOT NULL,
  id_rol INT NOT NULL,
  PRIMARY KEY (id_usuario,id_rol),
  CONSTRAINT fk_usuario_roles_usuario FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
  CONSTRAINT fk_usuario_roles_rol FOREIGN KEY (id_rol)
    REFERENCES roles(id_rol) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rol_permisos (
  id_rol INT NOT NULL,
  id_permiso INT NOT NULL,
  PRIMARY KEY (id_rol,id_permiso),
  CONSTRAINT fk_rol_permisos_rol FOREIGN KEY (id_rol)
    REFERENCES roles(id_rol) ON DELETE CASCADE,
  CONSTRAINT fk_rol_permisos_permiso FOREIGN KEY (id_permiso)
    REFERENCES permisos(id_permiso) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Excepciones individuales: permitido=1 concede, permitido=0 revoca.
CREATE TABLE IF NOT EXISTS usuario_permisos (
  id_usuario INT NOT NULL,
  id_permiso INT NOT NULL,
  permitido TINYINT(1) NOT NULL,
  PRIMARY KEY (id_usuario,id_permiso),
  CONSTRAINT fk_usuario_permisos_usuario FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
  CONSTRAINT fk_usuario_permisos_permiso FOREIGN KEY (id_permiso)
    REFERENCES permisos(id_permiso) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO roles(codigo,nombre) VALUES
('ADMIN','Administración'),
('MEDICO','Personal médico'),
('RECEPCION','Recepción'),
('VISOR','Consulta limitada');

INSERT IGNORE INTO permisos(codigo,descripcion) VALUES
('panel.ver','Acceder al panel'),
('pacientes.ver','Consultar pacientes'),
('pacientes.crear','Registrar pacientes'),
('pacientes.editar','Modificar pacientes'),
('medicos.ver','Consultar médicos'),
('medicos.crear','Registrar médicos'),
('medicos.editar','Modificar médicos'),
('tratamientos.ver','Consultar tratamientos'),
('tratamientos.crear','Registrar tratamientos'),
('tratamientos.editar','Modificar tratamientos'),
('usuarios.gestionar','Gestionar usuarios y permisos');

-- ADMIN: todos los permisos.
INSERT IGNORE INTO rol_permisos(id_rol,id_permiso)
SELECT r.id_rol,p.id_permiso FROM roles r CROSS JOIN permisos p WHERE r.codigo='ADMIN';

-- MEDICO: consultar pacientes y médicos; gestionar SOLO tratamientos propios.
INSERT IGNORE INTO rol_permisos(id_rol,id_permiso)
SELECT r.id_rol,p.id_permiso FROM roles r CROSS JOIN permisos p
WHERE r.codigo='MEDICO' AND p.codigo IN
('panel.ver','pacientes.ver','medicos.ver','tratamientos.ver','tratamientos.crear','tratamientos.editar');

-- RECEPCION: alta de pacientes, consulta de médicos; sin acceso a tratamientos.
INSERT IGNORE INTO rol_permisos(id_rol,id_permiso)
SELECT r.id_rol,p.id_permiso FROM roles r CROSS JOIN permisos p
WHERE r.codigo='RECEPCION' AND p.codigo IN
('panel.ver','pacientes.ver','pacientes.crear','medicos.ver');

-- VISOR: solo panel y directorio de médicos.
INSERT IGNORE INTO rol_permisos(id_rol,id_permiso)
SELECT r.id_rol,p.id_permiso FROM roles r CROSS JOIN permisos p
WHERE r.codigo='VISOR' AND p.codigo IN ('panel.ver','medicos.ver');

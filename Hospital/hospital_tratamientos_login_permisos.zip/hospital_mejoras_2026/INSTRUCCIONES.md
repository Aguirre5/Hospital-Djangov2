# Mejoras para tu sistema hospitalario: tratamientos + acceso granular

Compatible con tu entorno actual: **Windows 11, VS Code, Django 4.2.30, PyMySQL, XAMPP/MariaDB 10.4.32 y base `6hospi`**.

> **NO importes de nuevo `6hospi.sql` ni `BDFORHOSPITAL.sql` sobre tu base activa.** La exportación original no se modifica. Hacé un backup actualizado de `6hospi` antes de aplicar el script nuevo.

## 1. Copiar archivos (respetando rutas)

Este ZIP contiene la carpeta `Hospital/`. **Copiá el contenido de esta carpeta sobre tu proyecto**, aproximadamente en `C:\Htal\Hospital-Djangov2\Hospital`, donde está `manage.py`.

Los archivos ya existentes que se reemplazan son:

- `Hospital/settings.py` (misma configuración para `6hospi` y PyMySQL, más un procesador de contexto de permisos).
- `Hospital/urls.py` (rutas de login/logout y tratamientos).
- `app_hospital/views.py` (decoradores de permiso en páginas actuales y corrección de las comas de `agregar_medico`).
- `app_hospital/Templates/app_hospital/index.html` y `tratamientos.html` (interfaz manteniendo Bootstrap y paleta actual).

Los demás archivos son nuevos. **No reemplaces tu base de datos, migraciones, modelos, archivos de media ni el resto de los templates.** Si hiciste otros cambios locales en estos archivos desde que los subiste, compará antes de sobrescribir.

## 2. Crear las tablas de seguridad en phpMyAdmin

Con XAMPP/MySQL encendido, entrá a `http://localhost/phpmyadmin` y seleccioná la base **6hospi**.
En **SQL** o **Importar**, ejecutá únicamente el archivo nuevo:

`Hospital/sql/001_usuarios_permisos.sql`

Crea `usuarios`, `roles`, `permisos`, `usuario_roles`, `rol_permisos` y `usuario_permisos`. No altera tablas preexistentes de pacientes, médicos o tratamientos. Los roles preconfigurados son ADMIN, MEDICO, RECEPCION y VISOR.

## 3. Activar el Python correcto

En PowerShell dentro de VS Code:

```powershell
C:\Htal\Scripts\Activate.ps1
cd C:\Htal\Hospital-Djangov2\Hospital
python -m django --version
```

Debe responder **4.2.30**. No uses `py manage.py ...` si te ejecuta el Python global. Si te falta `pymysql`, instalalo en este entorno con `python -m pip install PyMySQL`.

## 4. Crear la tabla de sesiones de Django

```powershell
python manage.py migrate sessions
```

Esto solo aplica las migraciones **integradas de Django para sesiones**; no modifica las tablas hospitalarias ni necesita `makemigrations`.

## 5. Crear la primera cuenta administradora

```powershell
python manage.py crear_usuario_hospital admin --nombre "Administración" --rol ADMIN
```

Ingresá la contraseña de forma interactiva dos veces. No habrá contraseña predeterminada ni se guardará en texto plano: se almacena un hash de Django.

Para crear un médico, primero confirmá su `id_medico` en phpMyAdmin:

```powershell
python manage.py crear_usuario_hospital medico1 --nombre "Médico 1" --rol MEDICO --medico-id 1
```

Para una cuenta de recepción:

```powershell
python manage.py crear_usuario_hospital recepcion1 --nombre "Recepción" --rol RECEPCION
```

Para un visor:

```powershell
python manage.py crear_usuario_hospital visor1 --nombre "Consulta" --rol VISOR
```

## 6. Modificar un permiso individual (granularidad)

Por ejemplo, dar o quitar un permiso de creación de tratamientos:

```powershell
python manage.py permiso_usuario_hospital medico1 tratamientos.crear denegar
python manage.py permiso_usuario_hospital medico1 tratamientos.crear permitir
python manage.py permiso_usuario_hospital medico1 tratamientos.crear restaurar
```

`denegar` lo revoca, `permitir` lo concede y `restaurar` elimina la excepción individual para volver a la regla del rol. El permiso se valida en cada solicitud al servidor. Las cuentas sin rol ADMIN siempre necesitan un `id_medico` válido para consultar/crear/modificar tratamientos, **aunque tengan permiso**: es una protección de alcance adicional.

Otros códigos: `panel.ver`, `pacientes.ver`, `pacientes.crear`, `pacientes.editar`, `medicos.ver`, `medicos.crear`, `medicos.editar`, `tratamientos.ver`, `tratamientos.crear`, `tratamientos.editar`, `usuarios.gestionar`.

**Importante:** `pacientes.editar`, `medicos.editar` y `usuarios.gestionar` están reservados para incorporar vistas web futuras. El alta y edición de cuentas en esta primera entrega se administran desde los comandos de VS Code, no desde una pantalla web.

## 7. Levantar la aplicación

```powershell
python manage.py check
python manage.py runserver
```

Abrí `http://127.0.0.1:8000/login/`.

Las rutas nuevas son:

- `/login/`
- `/tratamientos/`
- `/tratamientos/agregar/`
- `/tratamientos/editar/<id>/`

`/logout/` acepta **solo POST**, para proteger la sesión de cierres forzados.

## 8. Verificar accesos

1. Sin iniciar sesión, abrir `/pacientes/` debe redirigir a login.
2. Usuario ADMIN puede ver todos los tratamientos y agregar uno existente a un paciente/médico activos.
3. Usuario MEDICO debe ver **solo los tratamientos** vinculados a su `id_medico` y no puede cambiarlo por una solicitud POST.
4. Usuario RECEPCION no debe poder acceder a `/tratamientos/` (403) y sí a `/pacientes/`.
5. Deshabilitar temporalmente una cuenta en phpMyAdmin (`UPDATE usuarios SET activo=0 WHERE username='...'`) debe invalidar su siguiente petición autenticada.

## Seguridad y límites de esta primera integración

- **Entorno de desarrollo local únicamente.** Antes de usar datos clínicos reales, faltan HTTPS, registro de auditoría de lecturas y modificaciones, rate limiting / bloqueo de intentos, gestión web de usuarios, recuperación segura de contraseñas, rotación de SECRET_KEY y pruebas de autorización integrales.
- Los templates heredados de pacientes y médicos todavía muestran botones “Agregar” aunque el servidor prohíbe ejecutar esas vistas sin permisos. Para ocultarlos en la UI, rodeá los botones con `{% if 'pacientes.crear' in permisos_hospital %}...{% endif %}` o `{% if 'medicos.crear' in permisos_hospital %}...{% endif %}` respectivamente. La seguridad real **ya se aplica en el servidor**.
- Los valores `id_paciente`, `id_medico` y fechas se validan en servidor y se envían a MariaDB en consultas parametrizadas.
- No se añadió ninguna migración automática a tablas hospitalarias.
